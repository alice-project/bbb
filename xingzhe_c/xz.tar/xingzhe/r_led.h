#ifndef __R_LED_H__
#define __R_LED_H__

int led_shining(void *);
int led_regist();
int set_led_on();
int set_led_off();

#endif

