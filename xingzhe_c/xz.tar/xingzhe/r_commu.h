#ifndef __R_COMMU_H__
#define __R_COMMU_H__

void *commu_proc(void *data);

#endif

