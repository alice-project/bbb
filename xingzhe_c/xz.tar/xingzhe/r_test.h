#ifndef __R_HM_TEST_H__
#define __R_HM_TEST_H__

int hm_test(void *d);
int parser_test_cmd();

#endif

