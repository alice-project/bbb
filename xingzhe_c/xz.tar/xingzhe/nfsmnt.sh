#!/bin/bash

mount -t nfs 192.168.1.104:/home/bbb/robot/hm /mnt/pc -o rw,sync

